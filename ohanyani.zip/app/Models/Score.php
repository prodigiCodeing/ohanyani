<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Score extends Model
{
    protected $table = "user_quize_table_migration";
    protected $guarded = "";
}
