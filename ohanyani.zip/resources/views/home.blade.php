
@section('content')
    <p>CONSENT
        By using our website, you hereby consent to our Privacy Policy and agree to its terms.
    </p>
    <p>
        INFORMATION WE COLLECT
        The personal information that you are asked to provide, and the reasons why you are asked to provide it, will be made clear to you at the point we ask you to provide your personal information. If you contact us directly, we may receive additional information about you such as your name, email address, phone number, the contents of the message and/or attachments you may send us, and any other information you may choose to provide. When you register for an Account, we may ask for your contact information, including items such as name, company name, address, email address, and telephone number.
    </p>
    <p>
        COOKIES AND WEB BEACONS
        These cookies are used to store information including visitors' preferences, and the pages on the website that the visitor accessed or visited. The information is used to optimize the users' experience by customizing our web page content based on visitors' browser type and/or other information. For more general information on cookies, please read "What Are Cookies".
    </p>

@endsection
